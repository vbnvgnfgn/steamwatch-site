# -*- coding: utf-8 -*-
"""Steam Watch: монитор цен Steam для украинского региона.

Текущая цена: Steam Store. История скидок: IsThereAnyDeal (необязательный ключ).
SteamDB автоматически не опрашивается: сайт запрещает scraping.
"""
from __future__ import annotations

import json
import os
import queue
import sys
import threading
import time
import webbrowser
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any

import customtkinter as ctk
import requests
from PIL import Image, ImageDraw, ImageFilter, ImageTk
import tkinter as tk
from tkinter import messagebox

APP_NAME = 'Steam Watch'
VERSION = '1.0.0'
STEAM_SEARCH_URL = 'https://store.steampowered.com/api/storesearch/'
STEAM_DETAILS_URL = 'https://store.steampowered.com/api/appdetails'
ITAD_URL = 'https://api.isthereanydeal.com'
STEAM_SHOP_ID = 61
HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) SteamWatch/1.0',
           'Accept': 'application/json'}

BG = '#080A17'
PANEL = '#111629'
PANEL2 = '#171D35'
STROKE = '#26304C'
WHITE = '#F4F6FF'
MUTED = '#8C9AB6'
CYAN = '#4CF3EF'
PURPLE = '#9B7BFF'
PINK = '#FF5CBD'
GREEN = '#63F7B2'
YELLOW = '#FFD277'

ctk.set_appearance_mode('dark')
ctk.set_default_color_theme('blue')


def data_file() -> Path:
    if sys.platform == 'win32':
        base = Path(os.environ.get('APPDATA') or Path.home())
    else:
        base = Path.home() / '.config'
    folder = base / 'NeonSteamWatch'
    folder.mkdir(parents=True, exist_ok=True)
    return folder / 'watchlist.json'


def load_settings() -> dict[str, Any]:
    try:
        data = json.loads(data_file().read_text(encoding='utf-8'))
        if isinstance(data, dict):
            return data
    except (OSError, json.JSONDecodeError, ValueError):
        pass
    return {'games': [], 'interval': '30 мин', 'alerts': True}


def save_settings(data: dict[str, Any]) -> None:
    target = data_file()
    tmp = target.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(target)


def steam_url(appid: int) -> str:
    return f'https://store.steampowered.com/app/{appid}/?cc=ua'


def steamdb_url(appid: int) -> str:
    return f'https://steamdb.info/app/{appid}/'


def money(minor: int | None, currency: str = 'UAH') -> str:
    if minor is None:
        return 'Нет данных'
    amount = minor / 100
    shown = f'{amount:,.0f}' if minor % 100 == 0 else f'{amount:,.2f}'
    shown = shown.replace(',', ' ').replace('.', ',')
    return f'{shown} грн' if currency == 'UAH' else f'{shown} {currency or "?"}'


def format_history_price(amount: Any, currency: str) -> str:
    if not isinstance(amount, (int, float)):
        return '—'
    return money(round(amount * 100), currency)


def get_json(url: str, *, params: dict | None = None, headers: dict | None = None,
             method: str = 'GET', payload: Any = None) -> Any:
    resp = requests.request(method, url, params=params, headers=headers or HEADERS,
                            json=payload, timeout=(6, 18))
    resp.raise_for_status()
    return resp.json()


def search_steam(title: str) -> list[dict[str, Any]]:
    response = get_json(STEAM_SEARCH_URL, params={'term': title, 'l': 'russian', 'cc': 'ua'})
    items = response.get('items', []) if isinstance(response, dict) else []
    results = []
    for item in items[:15]:
        try:
            appid = int(item['id'])
            name = str(item['name'])
        except (ValueError, KeyError, TypeError):
            continue
        results.append({'appid': appid, 'name': name})
    return results


def get_steam_price(appid: int) -> dict[str, Any]:
    raw = get_json(STEAM_DETAILS_URL, params={'appids': str(appid), 'cc': 'ua', 'l': 'russian',
                                              'filters': 'basic,price_overview'})
    entry = raw.get(str(appid), {}) if isinstance(raw, dict) else {}
    if not entry.get('success'):
        raise ValueError('Steam не вернул данные по этой игре.')
    item = entry.get('data') or {}
    price = item.get('price_overview')
    if item.get('is_free'):
        return {'name': str(item.get('name') or appid), 'final': 0, 'initial': 0,
                'discount': 0, 'currency': 'UAH', 'is_free': True, 'available': True}
    if not isinstance(price, dict):
        return {'name': str(item.get('name') or appid), 'final': None, 'initial': None,
                'discount': 0, 'currency': 'UAH', 'is_free': False, 'available': False}
    return {
        'name': str(item.get('name') or appid), 'final': int(price['final']),
        'initial': int(price['initial']),
        'discount': max(0, int(price.get('discount_percent') or 0)),
        'currency': str(price.get('currency') or 'UNKNOWN'),
        'is_free': False, 'available': True,
    }


def get_itad_record(appid: int, key: str) -> dict[str, Any]:
    """Максимальный % скидки в доступной ITAD истории STEAM/UA (не на всех площадках)."""
    headers = dict(HEADERS, **{'ITAD-API-Key': key})
    lookup = get_json(ITAD_URL + '/games/lookup/v1', params={'appid': appid}, headers=headers)
    if not lookup.get('found') or not (lookup.get('game') or {}).get('id'):
        return {'history': None, 'history_error': 'Игра отсутствует в истории ITAD'}
    gid = lookup['game']['id']
    history = get_json(ITAD_URL + '/games/history/v2',
                       params={'id': gid, 'country': 'UA', 'shops': STEAM_SHOP_ID,
                               'since': '2000-01-01T00:00:00Z'}, headers=headers)
    if not isinstance(history, list):
        raise ValueError('Неожиданный формат истории ITAD')
    records = []
    for item in history:
        if (item.get('shop') or {}).get('id') != STEAM_SHOP_ID:
            continue
        deal = item.get('deal')
        if not isinstance(deal, dict) or not isinstance(deal.get('cut'), (int, float)):
            continue
        records.append({'discount': int(deal['cut']),
                        'price': (deal.get('price') or {}).get('amount'),
                        'currency': (deal.get('price') or {}).get('currency', ''),
                        'date': str(item.get('timestamp') or '')[:10]})
    if not records:
        return {'history': None, 'history_error': 'Нет истории Steam для региона UA в ITAD'}
    # При равной скидке берём более низкую цену (в валюте одного региона).
    best = sorted(records, key=lambda r: (-r['discount'],
                  float(r['price']) if isinstance(r['price'], (float, int)) else float('inf')))[0]
    return {'history': best, 'history_error': ''}


def send_windows_toast(title: str, body: str, link: str | None = None) -> bool:
    if sys.platform != 'win32':
        return False
    try:
        from win11toast import toast
        if link:
            toast(title, body, on_click=link)
        else:
            toast(title, body)
        return True
    except Exception:
        return False


def make_banner(width=1120, height=152):
    im = Image.new('RGB', (width, height), '#10122A')
    px = im.load()
    for y in range(height):
        for x in range(width):
            px[x, y] = (12 + int(16*x/width), 14 + int(5*y/height),
                        32 + int(27*x/width))
    blooms = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(blooms)
    draw.ellipse((100, -190, 550, 240), fill=(76, 243, 239, 102))
    draw.ellipse((560, -250, 1100, 250), fill=(155, 123, 255, 95))
    draw.ellipse((915, -105, 1220, 235), fill=(255, 92, 189, 105))
    blooms = blooms.filter(ImageFilter.GaussianBlur(67))
    return Image.alpha_composite(im.convert('RGBA'), blooms)


class WatchApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f'{APP_NAME} · {VERSION}')
        self.geometry('1110x755')
        self.minsize(930, 650)
        self.configure(fg_color=BG)
        self.protocol('WM_DELETE_WINDOW', self.on_close)
        self.settings = load_settings()
        self.settings['games'] = [g for g in self.settings.get('games', [])
                                  if isinstance(g, dict) and isinstance(g.get('appid'), int)]
        self.jobs: queue.Queue[tuple] = queue.Queue()
        self.is_searching = False
        self.is_scanning = False
        self.is_history_loading = False
        self.next_scan_at = 0.0
        self.last_check = 'Ещё не проверялось'
        self.search_results: list[dict] = []
        self.selected = None
        self.banner_image = ImageTk.PhotoImage(make_banner())
        self._layout()
        self.render_cards()
        self.after(160, self.process_jobs)
        self.after(1600, self.initial_check)
        self.after(1000, self.timer_tick)

    def _label(self, parent, text, size=13, fg=WHITE, weight='normal', **kwargs):
        return ctk.CTkLabel(parent, text=text, text_color=fg,
                            font=ctk.CTkFont(family='Segoe UI', size=size, weight=weight),
                            **kwargs)

    def _button(self, parent, text, cmd, color=PURPLE, text_color=BG, height=39,
                hover=None, **kwargs):
        return ctk.CTkButton(parent, text=text, command=cmd, fg_color=color,
                             hover_color=hover or '#C3B1FF', text_color=text_color,
                             font=ctk.CTkFont(family='Segoe UI', size=13, weight='bold'),
                             corner_radius=12, height=height, **kwargs)

    def _layout(self):
        self.header = tk.Canvas(self, height=151, bg=BG, highlightthickness=0, bd=0)
        self.header.pack(fill='x', padx=15, pady=(14, 0))
        self.header.create_image(0, 0, anchor='nw', image=self.banner_image)
        self.header.create_text(33, 38, text='N E O N   / /   S T E A M   W A T C H',
                                anchor='w', fill=CYAN, font=('Segoe UI', 11, 'bold'))
        self.header.create_text(31, 89, text='Твои игры. Твои скидки.', anchor='w',
                                fill=WHITE, font=('Segoe UI', 26, 'bold'))
        self.header.create_text(34, 124, text='Мониторинг Steam  ·  Регион Украина  ·  UAH',
                                anchor='w', fill='#B9C4E9', font=('Segoe UI', 11))
        self.header.create_text(1025, 38, text='●  STEAM / UA', anchor='e',
                                fill=GREEN, font=('Segoe UI', 11, 'bold'))

        self.content = ctk.CTkFrame(self, fg_color='transparent')
        self.content.pack(fill='both', expand=True, padx=15, pady=(8, 12))
        self.content.grid_columnconfigure(0, minsize=310, weight=0)
        self.content.grid_columnconfigure(1, weight=1)
        self.content.grid_rowconfigure(0, weight=1)

        left = ctk.CTkFrame(self.content, fg_color=PANEL, corner_radius=18,
                            border_width=1, border_color=STROKE, width=317)
        left.grid(row=0, column=0, sticky='nsew', padx=(0, 10))
        left.grid_propagate(False)
        self._label(left, '01   ПОИСК ИГР', 12, CYAN, 'bold').pack(anchor='w', padx=18, pady=(18, 10))
        self._label(left, 'Выберите игру для\nмониторинга цен', 19, WHITE, 'bold',
                    justify='left').pack(anchor='w', padx=18, pady=(0, 14))
        self.search_entry = ctk.CTkEntry(left, placeholder_text='Название игры...', height=44,
                                         fg_color='#0B1122', border_color='#3A4F77',
                                         corner_radius=12, text_color=WHITE,
                                         font=('Segoe UI', 13))
        self.search_entry.pack(fill='x', padx=17)
        self.search_entry.bind('<Return>', lambda _: self.search_game())
        self.search_button = self._button(left, 'Найти в Steam  →', self.search_game, CYAN,
                                          hover='#9FFFFB')
        self.search_button.pack(fill='x', padx=17, pady=(10, 12))
        self._label(left, 'РЕЗУЛЬТАТЫ ПОИСКА', 11, MUTED, 'bold').pack(anchor='w', padx=18)
        self.results_frame = ctk.CTkScrollableFrame(left, fg_color='#0B1122', corner_radius=12,
                                                    border_width=1, border_color='#212A43')
        self.results_frame.pack(fill='both', expand=True, padx=16, pady=(7, 14))
        self.search_hint = self._label(self.results_frame, 'Введите название игры и\nнажмите «Найти».',
                                       12, MUTED, justify='center')
        self.search_hint.pack(pady=22)
        self._label(left, '02   ИСТОРИЯ СКИДОК', 12, PURPLE, 'bold').pack(anchor='w', padx=18, pady=(1, 9))
        self._label(left, 'API-ключ IsThereAnyDeal (необязательно)', 11, MUTED).pack(anchor='w', padx=18)
        self.api_entry = ctk.CTkEntry(left, placeholder_text='Вставьте API-ключ...', height=36,
                                      show='•', fg_color='#0B1122', border_color='#3A4F77',
                                      corner_radius=9)
        self.api_entry.pack(fill='x', padx=17, pady=(5, 6))
        self._button(left, 'Обновить исторический рекорд', self.fetch_histories,
                     '#292747', WHITE, 33, '#47406B').pack(fill='x', padx=17, pady=(0, 5))
        self._label(left, 'Ключ не сохраняется. Источник: ITAD, Steam/UA.',
                    10, MUTED).pack(anchor='w', padx=18, pady=(0, 14))

        right = ctk.CTkFrame(self.content, fg_color=PANEL, corner_radius=18,
                             border_width=1, border_color=STROKE)
        right.grid(row=0, column=1, sticky='nsew')
        bar = ctk.CTkFrame(right, fg_color='transparent')
        bar.pack(fill='x', padx=19, pady=(16, 11))
        self._label(bar, 'ОТСЛЕЖИВАЕМЫЕ ИГРЫ', 15, WHITE, 'bold').pack(side='left')
        self.counter_label = self._label(bar, '0 игр', 12, CYAN, 'bold')
        self.counter_label.pack(side='left', padx=12)
        self.scan_button = self._button(bar, '↻  Проверить', self.scan_prices, PURPLE,
                                        BG, 34, '#B29BFF', width=130)
        self.scan_button.pack(side='right')

        tiles = ctk.CTkFrame(right, fg_color='transparent')
        tiles.pack(fill='x', padx=18)
        tiles.grid_columnconfigure((0, 1, 2), weight=1)
        self.stat_track = self.stat_tile(tiles, 0, 'НА МОНИТОРИНГЕ', '0', CYAN)
        self.stat_sale = self.stat_tile(tiles, 1, 'СЕЙЧАС СО СКИДКОЙ', '0', GREEN)
        self.stat_record = self.stat_tile(tiles, 2, 'ПОСЛ. ПРОВЕРКА', '—', PURPLE)
        self.cards_frame = ctk.CTkScrollableFrame(right, fg_color='transparent')
        self.cards_frame.pack(fill='both', expand=True, padx=11, pady=(10, 4))

        bottom = ctk.CTkFrame(right, fg_color='#0C1224', corner_radius=12, height=77)
        bottom.pack(fill='x', padx=16, pady=(6, 13))
        bottom.pack_propagate(False)
        row1 = ctk.CTkFrame(bottom, fg_color='transparent')
        row1.pack(fill='x', padx=12, pady=(7, 3))
        self.status_label = self._label(row1, '●  Готов к мониторингу', 11, GREEN)
        self.status_label.pack(side='left')
        self.test_button = self._button(row1, 'Тест уведомления', self.test_notification,
                                        '#242D50', WHITE, 26, '#33426E', width=158)
        self.test_button.pack(side='right')
        row2 = ctk.CTkFrame(bottom, fg_color='transparent')
        row2.pack(fill='x', padx=12)
        self._label(row2, 'Интервал:', 11, MUTED).pack(side='left')
        self.interval_var = tk.StringVar(value=self.settings.get('interval', '30 мин'))
        if self.interval_var.get() not in {'15 мин', '30 мин', '60 мин', '180 мин'}:
            self.interval_var.set('30 мин')
        self.interval_menu = ctk.CTkOptionMenu(row2, values=['15 мин', '30 мин', '60 мин', '180 мин'],
                                                variable=self.interval_var, command=self.interval_changed,
                                                fg_color='#283154', button_color='#3A4777',
                                                button_hover_color='#57659A',
                                                dropdown_fg_color=PANEL2, height=26, width=92,
                                                font=('Segoe UI', 11))
        self.interval_menu.pack(side='left', padx=(7, 15))
        self.alert_var = tk.BooleanVar(value=bool(self.settings.get('alerts', True)))
        self.alert_switch = ctk.CTkSwitch(row2, text='Уведомления Windows',
                                          variable=self.alert_var, command=self.alert_changed,
                                          progress_color=CYAN, button_color=WHITE,
                                          font=('Segoe UI', 11), text_color=MUTED)
        self.alert_switch.pack(side='left')

    def stat_tile(self, parent, col, headline, number, color):
        panel = ctk.CTkFrame(parent, fg_color=PANEL2, corner_radius=12,
                             border_width=1, border_color='#2B3150')
        panel.grid(row=0, column=col, sticky='ew', padx=(0 if col == 0 else 4,
                                                       0 if col == 2 else 4))
        self._label(panel, headline, 10, MUTED, 'bold').pack(anchor='w', padx=12, pady=(9, 0))
        value = self._label(panel, number, 25, color, 'bold')
        value.pack(anchor='w', padx=12, pady=(0, 7))
        return value

    def set_status(self, msg: str, color=MUTED):
        self.status_label.configure(text='●  ' + msg, text_color=color)

    def persist(self):
        self.settings['interval'] = self.interval_var.get()
        self.settings['alerts'] = bool(self.alert_var.get())
        try:
            save_settings(self.settings)
        except OSError as exc:
            self.set_status(f'Не удалось сохранить список: {exc}', PINK)

    def interval_changed(self, _=None):
        self.next_scan_at = time.monotonic() + self.interval_seconds()
        self.persist()

    def alert_changed(self):
        self.persist()

    def interval_seconds(self):
        return int(self.interval_var.get().split()[0]) * 60

    def search_game(self):
        query = self.search_entry.get().strip()
        if len(query) < 2 or self.is_searching:
            if len(query) < 2:
                self.set_status('Введите хотя бы 2 символа для поиска', YELLOW)
            return
        self.is_searching = True
        self.search_button.configure(state='disabled', text='Поиск...')
        self.set_status('Поиск по каталогу Steam...', CYAN)
        threading.Thread(target=self.search_worker, args=(query,), daemon=True).start()

    def search_worker(self, query):
        try:
            self.jobs.put(('search_done', search_steam(query), None))
        except Exception as exc:
            self.jobs.put(('search_done', [], str(exc)))

    def show_search_results(self, results):
        for widget in self.results_frame.winfo_children():
            widget.destroy()
        if not results:
            self._label(self.results_frame, 'Ничего не найдено.\nУточните название игры.',
                        12, MUTED, justify='center').pack(pady=25)
            return
        watched = {g['appid'] for g in self.settings['games']}
        for result in results:
            card = ctk.CTkFrame(self.results_frame, fg_color=PANEL2, corner_radius=10)
            card.pack(fill='x', pady=3, padx=2)
            self._label(card, result['name'], 12, WHITE, 'bold', wraplength=250,
                        justify='left').pack(anchor='w', padx=10, pady=(8, 0))
            row = ctk.CTkFrame(card, fg_color='transparent')
            row.pack(fill='x', padx=10, pady=(3, 7))
            self._label(row, f"App ID: {result['appid']}", 10, MUTED).pack(side='left')
            already = result['appid'] in watched
            self._button(row, '✓ Добавлено' if already else '+ Добавить',
                         lambda r=result: self.add_game(r),
                         '#25354E' if already else CYAN,
                         GREEN if already else BG, 27, '#99FFFF', width=104,
                         state='disabled' if already else 'normal').pack(side='right')

    def add_game(self, result):
        if any(g['appid'] == result['appid'] for g in self.settings['games']):
            return
        self.settings['games'].append({'appid': result['appid'], 'name': result['name'],
                                       'price': None, 'history': None, 'history_error': '',
                                       'last_notified': None})
        self.persist()
        self.show_search_results(self.search_results)
        self.render_cards()
        self.set_status(f"Добавлено: {result['name']}", GREEN)
        self.scan_prices()
        if self.api_entry.get().strip():
            self.fetch_histories()

    def remove_game(self, appid):
        self.settings['games'] = [g for g in self.settings['games'] if g['appid'] != appid]
        self.persist()
        self.render_cards()
        if self.search_results:
            self.show_search_results(self.search_results)
        self.set_status('Игра удалена из мониторинга', MUTED)

    def render_cards(self):
        for widget in self.cards_frame.winfo_children():
            widget.destroy()
        games = self.settings['games']
        self.counter_label.configure(text=f'{len(games)} игр')
        self.stat_track.configure(text=str(len(games)))
        self.stat_sale.configure(text=str(sum(
            bool((g.get('price') or {}).get('discount', 0) > 0) for g in games)))
        self.stat_record.configure(text=self.last_check if self.last_check != 'Ещё не проверялось' else '—')
        if not games:
            empty = ctk.CTkFrame(self.cards_frame, fg_color=PANEL2, corner_radius=15,
                                 border_width=1, border_color=STROKE)
            empty.pack(fill='both', expand=True, padx=7, pady=12)
            self._label(empty, '◈', 48, PURPLE, 'bold').pack(pady=(41, 7))
            self._label(empty, 'Пока нет отслеживаемых игр', 19, WHITE, 'bold').pack()
            self._label(empty, 'Найдите игру слева и добавьте её в список.\n'
                        'Цены будут обновляться автоматически.', 12, MUTED,
                        justify='center').pack(pady=(7, 42))
            return
        for g in games:
            self.make_card(g)

    def make_card(self, game):
        price = game.get('price') or {}
        discount = int(price.get('discount') or 0)
        card = ctk.CTkFrame(self.cards_frame, fg_color=PANEL2, corner_radius=15,
                            border_width=1, border_color='#334367' if discount else '#2A3150')
        card.pack(fill='x', padx=5, pady=6)
        top = ctk.CTkFrame(card, fg_color='transparent')
        top.pack(fill='x', padx=15, pady=(12, 7))
        self._label(top, game['name'], 17, WHITE, 'bold', wraplength=395,
                    justify='left').pack(side='left', anchor='w')
        self._button(top, '✕', lambda aid=game['appid']: self.remove_game(aid),
                     '#30273E', PINK, 27, '#593753', width=30).pack(side='right')
        if discount:
            chip_text, chip_color = f'  СКИДКА −{discount}%  ', GREEN
        elif price.get('is_free'):
            chip_text, chip_color = '  БЕСПЛАТНО  ', CYAN
        else:
            chip_text, chip_color = '  БЕЗ СКИДКИ  ', MUTED
        self._label(card, chip_text, 11, chip_color, 'bold').pack(anchor='w', padx=15)
        price_row = ctk.CTkFrame(card, fg_color='transparent')
        price_row.pack(fill='x', padx=15, pady=(10, 8))
        price_row.grid_columnconfigure((0, 1, 2), weight=1)
        currency = price.get('currency', 'UAH')
        initial = price.get('initial')
        final = price.get('final')
        current = money(final, currency) if price else 'Ожидание проверки'
        regular = money(initial, currency) if price else '—'
        sale = money(final, currency) if discount else 'Скидки нет'
        self.small_price(price_row, 0, 'ЦЕНА СЕЙЧАС', current, WHITE)
        self.small_price(price_row, 1, 'ОБЫЧНАЯ ЦЕНА', regular, MUTED)
        self.small_price(price_row, 2, 'ЦЕНА ПО СКИДКЕ', sale, GREEN if discount else MUTED)
        line = ctk.CTkFrame(card, fg_color='#313857', height=1)
        line.pack(fill='x', padx=15, pady=(5, 8))
        record_row = ctk.CTkFrame(card, fg_color='transparent')
        record_row.pack(fill='x', padx=15, pady=(0, 12))
        hist = game.get('history')
        if hist:
            record_text = f"Исторический максимум: −{hist['discount']}%"
            if isinstance(hist.get('price'), (int, float)):
                record_text += f"  ·  {format_history_price(hist['price'], hist.get('currency', ''))}"
            record_text += '  ·  ITAD'
        elif game.get('history_error'):
            record_text = 'История: ' + str(game['history_error'])
        else:
            record_text = 'Исторический максимум: нет данных (нужен ключ ITAD)'
        self._label(record_row, record_text, 11, PURPLE, 'bold',
                    wraplength=420, justify='left').pack(side='left')
        self._button(record_row, 'SteamDB ↗',
                     lambda aid=game['appid']: webbrowser.open(steamdb_url(aid)),
                     '#252E4C', CYAN, 27, '#34466B', width=100).pack(side='right')

    def small_price(self, frame, column, header, value, color):
        inner = ctk.CTkFrame(frame, fg_color='transparent')
        inner.grid(row=0, column=column, sticky='w')
        self._label(inner, header, 9, MUTED, 'bold').pack(anchor='w')
        self._label(inner, value, 15, color, 'bold').pack(anchor='w')

    def initial_check(self):
        if self.settings['games']:
            self.scan_prices()

    def scan_prices(self):
        if self.is_scanning or not self.settings['games']:
            if not self.settings['games']:
                self.set_status('Сначала добавьте игру', YELLOW)
            return
        self.is_scanning = True
        self.scan_button.configure(state='disabled', text='Проверка...')
        self.set_status('Получаем цены из Steam...', CYAN)
        ids = [g['appid'] for g in self.settings['games']]
        threading.Thread(target=self.scan_worker, args=(ids,), daemon=True).start()

    def scan_worker(self, ids):
        prices = {}
        errors = []
        for i, appid in enumerate(ids):
            try:
                prices[appid] = get_steam_price(appid)
            except Exception as exc:
                errors.append(f'{appid}: {str(exc)[:90]}')
            if i < len(ids) - 1:
                time.sleep(.5)
        self.jobs.put(('scan_done', prices, errors))

    def fetch_histories(self):
        key = self.api_entry.get().strip()
        if not key:
            self.set_status('Для истории вставьте ключ IsThereAnyDeal', YELLOW)
            return
        if not self.settings['games']:
            self.set_status('Сначала добавьте игру', YELLOW)
            return
        if self.is_history_loading:
            return
        self.is_history_loading = True
        ids = [g['appid'] for g in self.settings['games']]
        self.set_status('Загружаем историю скидок из ITAD...', PURPLE)
        threading.Thread(target=self.history_worker, args=(ids, key), daemon=True).start()

    def history_worker(self, ids, key):
        records = {}
        errors = []
        for i, appid in enumerate(ids):
            try:
                records[appid] = get_itad_record(appid, key)
            except requests.HTTPError as exc:
                errors.append(f'ITAD HTTP {exc.response.status_code} ({appid})')
            except Exception as exc:
                errors.append(f'{appid}: {str(exc)[:65]}')
            if i < len(ids) - 1:
                time.sleep(.5)
        self.jobs.put(('history_done', records, errors))

    def test_notification(self):
        if sys.platform != 'win32':
            self.set_status('Системные уведомления работают в Windows 10/11', YELLOW)
            return
        def worker():
            ok = send_windows_toast('Steam Watch · тест',
                                    'Уведомления о скидках включены. Это тестовое сообщение.')
            self.jobs.put(('toast_test', ok))
        threading.Thread(target=worker, daemon=True).start()
        self.set_status('Отправляем тестовое уведомление...', CYAN)

    def apply_prices(self, prices, errors):
        notifications = []
        for game in self.settings['games']:
            result = prices.get(game['appid'])
            if result is None:
                continue
            game['price'] = result
            game['name'] = result['name']
            cut = int(result.get('discount') or 0)
            if cut > 0 and result.get('final') is not None:
                signature = f"{cut}:{result.get('final')}:{result.get('currency')}"
                if game.get('last_notified') != signature:
                    game['last_notified'] = signature
                    notifications.append((game['name'], cut, result['final'],
                                          result.get('currency', 'UAH'), game['appid']))
            else:
                game['last_notified'] = None
        self.is_scanning = False
        self.last_check = datetime.now().strftime('%H:%M')
        self.next_scan_at = time.monotonic() + self.interval_seconds()
        self.scan_button.configure(state='normal', text='↻  Проверить')
        self.persist()
        self.render_cards()
        if errors:
            self.set_status(f'Обновлено {len(prices)}; ошибок: {len(errors)}. ' + errors[0][:70], YELLOW)
        else:
            self.set_status(f'Цены обновлены в {self.last_check} · Steam / UA', GREEN)
        if self.alert_var.get():
            for name, cut, final, currency, appid in notifications:
                text = f'На игру «{name}» сейчас действует скидка {cut}%! Цена: {money(final, currency)}.'
                threading.Thread(target=send_windows_toast,
                                 args=('Steam · найдена скидка!', text, steam_url(appid)),
                                 daemon=True).start()

    def process_jobs(self):
        try:
            while True:
                event = self.jobs.get_nowait()
                kind = event[0]
                if kind == 'search_done':
                    _, results, error = event
                    self.is_searching = False
                    self.search_button.configure(state='normal', text='Найти в Steam  →')
                    self.search_results = results
                    self.show_search_results(results)
                    self.set_status('Результатов: ' + str(len(results)) if not error
                                    else 'Не удалось найти игру: ' + error[:85],
                                    GREEN if not error else PINK)
                elif kind == 'scan_done':
                    _, prices, errors = event
                    self.apply_prices(prices, errors)
                elif kind == 'history_done':
                    _, records, errors = event
                    self.is_history_loading = False
                    for game in self.settings['games']:
                        record = records.get(game['appid'])
                        if record is not None:
                            game.update(record)
                    self.persist()
                    self.render_cards()
                    self.set_status('История загружена для ' + str(len(records)) + ' игр' if not errors
                                    else 'Ошибки ITAD: ' + errors[0][:105],
                                    PURPLE if not errors else YELLOW)
                elif kind == 'toast_test':
                    self.set_status('Тест отправлен. Проверьте уведомления Windows.' if event[1]
                                    else 'Не удалось отправить toast. Проверьте win11toast и настройки Windows.',
                                    GREEN if event[1] else PINK)
        except queue.Empty:
            pass
        if self.winfo_exists():
            self.after(160, self.process_jobs)

    def timer_tick(self):
        if (self.settings['games'] and not self.is_scanning and self.next_scan_at > 0
                and time.monotonic() >= self.next_scan_at):
            self.scan_prices()
        if self.winfo_exists():
            self.after(1000, self.timer_tick)

    def on_close(self):
        self.persist()
        self.destroy()


if __name__ == '__main__':
    try:
        app = WatchApp()
        app.mainloop()
    except Exception as exc:
        # Для .pyw консоли нет, поэтому ошибку показываем в отдельном диалоге.
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror(APP_NAME, f'Ошибка запуска:\n{exc}')
            root.destroy()
        except Exception:
            pass
        raise
