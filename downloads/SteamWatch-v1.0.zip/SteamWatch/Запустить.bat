@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Steam Watch - setup and launch
where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python not found. Install Python 3.11 or 3.12 from https://www.python.org/downloads/
    echo During installation, enable Add Python to PATH.
    pause
    exit /b 1
  )
  set "PY=python"
)
echo [1/2] Installing / checking Python packages...
%PY% -m pip install -r requirements.txt
if errorlevel 1 (
  echo Failed to install dependencies. See error above.
  pause
  exit /b 1
)
echo [2/2] Launching Steam Watch...
%PY% "%~dp0SteamWatch.pyw"
if errorlevel 1 (
  echo Program exited with error.
  pause
)
